import { TraceEvent } from "./sсhemas";

const TRACE_API_URL =
  typeof window === "undefined"
    ? process.env.TRACE_API_URL 
    : "/api/trace";             

export async function sendTraceEvent(
  event: TraceEvent
): Promise<void> {
  if (!TRACE_API_URL) {
    console.warn("[TRACE] TRACE_API_URL is not defined");
    return;
  }

  try {
    await fetch(TRACE_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(event),
      keepalive: true,
    });
  } catch {
    
  }
}
