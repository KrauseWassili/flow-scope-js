// import { EventNode } from "../nodes/systemNodes";

// export type ObservedNodeInfo = {
//   timestamp: number;
//   outcome?: "success" | "error";
// };

// export type ObservedEvent = {
//   traceId: string;
//   type: string;
//   node: Partial<Record<EventNode, ObservedNodeInfo>>;
// };
