import { NextResponse } from "next/server";
import { isEventType } from "@/lib/events/guards/isEventType";
import { eventSchemas } from "@/lib/trace/sсhemas";

const WS_SERVER_URL = process.env.WS_SERVER_URL;

export async function POST(req: Request) {
  // --- ENV guard ---
  if (!WS_SERVER_URL) {
    console.error("[API][TRACE] WS_SERVER_URL is not defined");
    return NextResponse.json(
      { error: "Trace backend is not configured" },
      { status: 500 }
    );
  }

  // --- Parse JSON ---
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  // --- Basic shape check ---
  if (typeof body !== "object" || body === null || !("type" in body)) {
    return NextResponse.json({ error: "Invalid body" }, { status: 400 });
  }

  // --- Event type guard ---
  const rawType = (body as any).type;
  if (!isEventType(rawType)) {
    return NextResponse.json({ error: "Unknown event type" }, { status: 400 });
  }

  // --- Schema validation ---
  const schema = eventSchemas[rawType];
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(parsed.error.format(), { status: 400 });
  }

  const { traceId, type } = parsed.data;

  console.log("[API][TRACE INGEST]:", traceId, type);

  // --- Forward to ws-server with timeout ---
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2000);

  try {
    const res = await fetch(`${WS_SERVER_URL}/trace`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(parsed.data),
      signal: controller.signal,
    });

    if (!res.ok) {
      console.error(
        "[API][TRACE] ws-server responded with status",
        res.status
      );
      return NextResponse.json(
        { error: "Trace backend error" },
        { status: 502 }
      );
    }
  } catch (err: any) {
    console.error("[API][TRACE FORWARD ERROR]", err?.message ?? err);
    return NextResponse.json(
      { error: "Failed to forward trace event" },
      { status: 502 }
    );
  } finally {
    clearTimeout(timeout);
  }

  // --- Success ---
  return NextResponse.json({ ok: true, traceId });
}
